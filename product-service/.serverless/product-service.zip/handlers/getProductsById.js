/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	// The require scope
/******/ 	var __webpack_require__ = {};
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "getProductsById": () => (/* binding */ getProductsById)
});

;// CONCATENATED MODULE: external "source-map-support/register"
const register_namespaceObject = require("source-map-support/register");
;// CONCATENATED MODULE: external "@aws-sdk/lib-dynamodb"
const lib_dynamodb_namespaceObject = require("@aws-sdk/lib-dynamodb");
;// CONCATENATED MODULE: external "@aws-sdk/client-dynamodb"
const client_dynamodb_namespaceObject = require("@aws-sdk/client-dynamodb");
;// CONCATENATED MODULE: ./handlers/ddb-client.js


// Set the AWS Region.
const REGION = "us-east-1"; //e.g. "us-east-1"
// Create an Amazon DynamoDB service client object.
const ddbClient = new client_dynamodb_namespaceObject.DynamoDBClient({
  apiVersion: "latest",
  credentials: {
    accessKeyId: "ASIATHMZAGEGJM4CYJJ5",
    secretAccessKey: "0b1ogK3ELxXPUz4Y2d7k5hFQqq3ZIK0uFce36uqb",
    sessionToken: "IQoJb3JpZ2luX2VjEAMaCXVzLWVhc3QtMSJHMEUCIQCkvX9D3/V7AdmyhmR3drCjR6PCPkOy+rUgKGdC5vB1zAIgdK9jc5/E1HJXdJfzXGJHzg5ydS3McUHk0o7V//QVOSgqoAMI7P//////////ARAAGgwyMjIwNDg1NjM0NjgiDGUjWD0mmKOOmlSD6Sr0AiRBr81jBg5xx9XKXilwcaPJygNHfUEnkmpeGZseTsiV7rggR8U6eyIERYWL551/GT2tnN9C4YUBkZOoXL5xr8Is2XIT0lyxNy8Do7jhVMZZC+KaD2kFe6v0vDS7fBReqgNAyVVXmZMaIFrM69bjwGFWBSL6Q3SQNO3cMSpdwn54JmVP2yiU0iTafCBqT4lcpbLtrzcOASk53JRB1qv8FwPpRox5bCdb9dq/J0xxulbdzqXFidfYRuewMKH1VtO+4fWm2IadrlR/bMqnqvTbOEEoIyQVYsOj6fZAKj2SEnMHKBJY7g7Va44fwuCAqtVmNR6r+SG7wiALECbMPCzrrgsyOrSjliKgYN5+oTNZYrcaPQxjJ4V1P0ZeGndw/FnV2M8eT/X9pCeBMuxu8OirBsgDQUBO/qmLiwxi23x3hEkZDszH94fzI5vz1sa9epTfdfa7c5i4Z8Gr/jRsEMm4/V550B6cXmXvtI1rdZvCuAXKVD5z6zCe2uShBjqmAR2XBj5DCq2t+PmlKTLrGRaERMDYiK407KctgC4j6P0tGXdkJ6LxPpPzO0PC1qV2qOoLoFE+7yeIj5U9Gkimv0lnvFo7RsELqLPWcGsq3+cb3fAJyYttmWwBYaimcDXwDIR4flSlMlPadjG15xRO+sh0GFDiYvkg3EhYVLy5OlK/io057ozNrkUTz0n2pc8rYiIDZSoO/EHKN178DrbgbmSHae6YpUo="
  },
  region: "us-east-1"
});

;// CONCATENATED MODULE: ./handlers/ddb-doc-client.js



const marshallOptions = {
  // Whether to automatically convert empty strings, blobs, and sets to `null`.
  convertEmptyValues: false,
  // false, by default.
  // Whether to remove undefined values while marshalling.
  removeUndefinedValues: false,
  // false, by default.
  // Whether to convert typeof object to map attribute.
  convertClassInstanceToMap: false // false, by default.
};

const unmarshallOptions = {
  // Whether to return numbers as a string instead of converting them to native JavaScript numbers.
  wrapNumbers: false // false, by default.
};

const translateConfig = {
  marshallOptions,
  unmarshallOptions
};

// Create the DynamoDB Document client.
const ddbDocClient = lib_dynamodb_namespaceObject.DynamoDBDocumentClient.from(ddbClient, translateConfig);

;// CONCATENATED MODULE: ./handlers/getProductsById.js



const getProductsById = async event => {
  const myTable = 'AWS_Products';
  const myTable2 = 'AWS_Products_Stock';
  try {
    const productId = event.pathParameters.productId;
    console.log("Product Id", productId);
    const product = (await ddbDocClient.send(new lib_dynamodb_namespaceObject.GetCommand({
      TableName: myTable,
      Key: {
        id: productId
      }
    }))).Item;
    console.log(product);
    const productStockCount = (await ddbDocClient.send(new lib_dynamodb_namespaceObject.GetCommand({
      TableName: myTable2,
      Key: {
        product_id: productId
      }
    }))).Item.count;
    if (!product && !productStockCount) {
      throw new Error('Product was not found');
    }
    return {
      statusCode: 200,
      headers: {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Credentials': true,
        'Access-Control-Allow-Headers': '*'
      },
      body: JSON.stringify({
        ...product,
        count: productStockCount
      })
    };
  } catch (error) {
    return {
      statusCode: 500,
      body: error ?? {
        message: 'Request for product id is invalid'
      }
    };
  }
};
var __webpack_export_target__ = exports;
for(var i in __webpack_exports__) __webpack_export_target__[i] = __webpack_exports__[i];
if(__webpack_exports__.__esModule) Object.defineProperty(__webpack_export_target__, "__esModule", { value: true });
/******/ })()
;
//# sourceMappingURL=getProductsById.js.map